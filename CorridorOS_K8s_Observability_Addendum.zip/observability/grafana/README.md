Import dashboard_corridoros_overview.json in Grafana.
