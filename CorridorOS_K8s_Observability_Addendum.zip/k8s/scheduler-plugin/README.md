# Corridor Scheduler Plugin (design)
